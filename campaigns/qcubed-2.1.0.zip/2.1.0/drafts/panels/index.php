<?php
header("Location: ../../assets/_core/php/_devtools/panel_drafts.php");
?>
