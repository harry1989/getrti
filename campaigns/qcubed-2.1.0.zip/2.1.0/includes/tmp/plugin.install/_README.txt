Just drop plugin .zip files into this directory, and run the Plugin Auto-Installer. 
The plugins from this folder will be automatically installed. 