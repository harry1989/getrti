This directory is used by the QCache object to cache any
files for use by the system.  Please be sure that the webserver
service has full read/write/execute privileges for the cache
directory.
