<?php
	// This example footer.inc.php is intended to be modfied for your application.
?>
			</div>
			<div id="footer">
				<div id="footerLeft"><a href="http://qcu.be/"><img src="<?php _p(__VIRTUAL_DIRECTORY__ . __IMAGE_ASSETS__ . '/qcubed_logo_footer.png'); ?>" alt="QCubed - A Rapid Prototyping PHP5 Framework" /></a></div>
				<div id="footerRight">
					<div><span class="footerSmall">For more information, please visit the QCubed website at <a href="http://www.qcu.be/" class="footerLink">http://www.qcu.be/</a></span></div>
					<div><span class="footerSmall">Questions, comments, or issues can be discussed at the <a href="http://qcu.be/forum" class="footerLink">Examples Site Forum</a></span></div>
				</div>
			</div>
		</div>
	</body>
</html>