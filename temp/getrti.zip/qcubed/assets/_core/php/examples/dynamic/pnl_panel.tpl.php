<h3>This is the Panel of Textboxes</h3>
Note how we can still use <b>$this</b> in the template to refer to form-level objects, like <b>$this->strMessage</b>:
"<?php _p($this->strMessage); ?>"<br/><br/>