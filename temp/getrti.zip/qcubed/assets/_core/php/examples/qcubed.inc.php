<?php
// Include prepend.inc to load QCubed
require_once(dirname(__FILE__).'/../qcubed.inc.php');
?>
