<?php
	// This is the HTML template include file (.tpl.php) for AddressListPanel.
	// Remember that this is a DRAFT.  It is MEANT to be altered/modified.
	// Be sure to move this out of the drafts/dashboard directory before modifying to ensure that subsequent 
	// code re-generations do not overwrite your changes.
?>
		</td>
	</tr>
	<tr>
		<td colspan="6">
		<table border="0" cellpadding="0" cellspacing="0" width="100%">
			<tr>
				<td><?php $_CONTROL->dtgAddresses->Render(); ?></td>
			</tr>
		</table>
		</td>
	</tr>
	<tr>
		<td>	

