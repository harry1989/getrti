<?php
	// This is the HTML template include file (.tpl.php) for the loksabha_edit.php
	// form DRAFT page.  Remember that this is a DRAFT.  It is MEANT to be altered/modified.

	// Be sure to move this out of the generated/ subdirectory before modifying to ensure that subsequent
	// code re-generations do not overwrite your changes.

	$strPageTitle = QApplication::Translate('Loksabha') . ' - ' . $this->mctLoksabha->TitleVerb;
	require(__CONFIGURATION__ . '/header.inc.php');
?>
	<?php $this->RenderBegin() ?>

	<h1><?php _p($this->mctLoksabha->TitleVerb); ?> <?php _t('Loksabha')?></h1>

	<div class="form-controls">
<?php $this->lblId->RenderWithName(); ?><?php $this->txtName->RenderWithName(); ?><?php $this->txtDob->RenderWithName(); ?><?php $this->txtParty->RenderWithName(); ?><?php $this->txtConstituency->RenderWithName(); ?><?php $this->txtState->RenderWithName(); ?><?php $this->txtPAddress->RenderWithName(); ?><?php $this->txtPTelephone->RenderWithName(); ?><?php $this->txtDAddress->RenderWithName(); ?><?php $this->txtDTelephone->RenderWithName(); ?><?php $this->txtEmail->RenderWithName(); ?>	</div>

	<div class="form-actions">
		<div class="form-save"><?php $this->btnSave->Render(); ?></div>
		<div class="form-cancel"><?php $this->btnCancel->Render(); ?></div>
		<div class="form-delete"><?php $this->btnDelete->Render(); ?></div>
	</div>

	<?php $this->RenderEnd() ?>

<?php require(__CONFIGURATION__ .'/footer.inc.php'); ?>