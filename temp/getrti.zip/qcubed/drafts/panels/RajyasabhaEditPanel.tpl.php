<?php
	// This is the HTML template include file (.tpl.php) for rajyasabhaEditPanel.
	// Remember that this is a DRAFT.  It is MEANT to be altered/modified.
	// Be sure to move this out of the drafts/dashboard subdirectory before modifying to ensure that subsequent
	// code re-generations do not overwrite your changes.
?>
	<div class="form-controls">
<?php $_CONTROL->lblId->RenderWithName(); ?><?php $_CONTROL->txtName->RenderWithName(); ?><?php $_CONTROL->txtDAddress->RenderWithName(); ?><?php $_CONTROL->txtDTelephone->RenderWithName(); ?><?php $_CONTROL->txtPAddress->RenderWithName(); ?><?php $_CONTROL->txtPTelephone->RenderWithName(); ?><?php $_CONTROL->txtDob->RenderWithName(); ?><?php $_CONTROL->txtParty->RenderWithName(); ?><?php $_CONTROL->txtState->RenderWithName(); ?><?php $_CONTROL->txtEmail->RenderWithName(); ?>	</div>

	<div class="form-actions">
		<div class="form-save"><?php $_CONTROL->btnSave->Render(); ?></div>
		<div class="form-cancel"><?php $_CONTROL->btnCancel->Render(); ?></div>
		<div class="form-delete"><?php $_CONTROL->btnDelete->Render(); ?></div>
	</div>