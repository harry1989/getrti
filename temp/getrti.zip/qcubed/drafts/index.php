<?php
header("Location: ../assets/_core/php/_devtools/form_drafts.php");
?>
