<?php
	// This is the HTML template include file (.tpl.php) for the users_edit.php
	// form DRAFT page.  Remember that this is a DRAFT.  It is MEANT to be altered/modified.

	// Be sure to move this out of the generated/ subdirectory before modifying to ensure that subsequent
	// code re-generations do not overwrite your changes.

	$strPageTitle = QApplication::Translate('Users') . ' - ' . $this->mctUsers->TitleVerb;
	require(__CONFIGURATION__ . '/header.inc.php');
?>
	<?php $this->RenderBegin() ?>

	<h1><?php _p($this->mctUsers->TitleVerb); ?> <?php _t('Users')?></h1>

	<div class="form-controls">
<?php $this->lblId->RenderWithName(); ?><?php $this->txtUsername->RenderWithName(); ?><?php $this->txtOauthProvider->RenderWithName(); ?><?php $this->txtOauthUid->RenderWithName(); ?>	</div>

	<div class="form-actions">
		<div class="form-save"><?php $this->btnSave->Render(); ?></div>
		<div class="form-cancel"><?php $this->btnCancel->Render(); ?></div>
		<div class="form-delete"><?php $this->btnDelete->Render(); ?></div>
	</div>

	<?php $this->RenderEnd() ?>

<?php require(__CONFIGURATION__ .'/footer.inc.php'); ?>